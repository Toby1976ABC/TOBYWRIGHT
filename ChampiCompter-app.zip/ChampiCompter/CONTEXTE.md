# ChampiCompter — Cabane & Cie

Application web (un seul fichier HTML, hors-ligne) de comptage des meules de champignons (Agaricus) par photo :
comptage par classe de calibre, situation de la charge au m², prévision de cueille jour par jour.

## Fichiers
- `champiscompter.html` : version 2.0.0 d'origine (moteur de comptage, prévision, historique local, export CSV/JSON).
- `maquettes-mobile/` : maquettes des 4 écrans au format téléphone (390 px) — Relevé, Résultats, Historique, Réglages.
  Logo Cabane & Cie en tête de chaque écran (`cabane-logo.png`).

## Choix retenus pour le mobile
- Onglets en barre basse (Relevé · Historique · Réglages), cibles tactiles ≥ 44 px.
- Champs à 16 px (pas de zoom iOS), formulaires sur 2 colonnes.
- Chiffres clés en grille 2×2, photos bord à bord, tableaux sans défilement horizontal.
- Palette : fond #EDF0E9, encre #1B211B, accent #2B6A68, sauge #8CA277 ; titres Georgia, texte system-ui.

## État au 01/10/2026 — v2.1.0
- Maquettes reportées dans l'application (`champiscompter/index.html`) : logo, barre d'onglets basse,
  écran Résultats séparé avec retour, bouton « Prendre la photo » + galerie, historique sans défilement horizontal.
  Moteur de comptage et de prévision **inchangés** (testé : 60/60 sujets détectés sur image de synthèse).
- Application installable (PWA) : `manifest.webmanifest`, `sw.js` (hors-ligne), icônes iOS/Android,
  rubrique « Installer sur le téléphone » dans Réglages, bandeau de mise à jour.
- Version fichier unique : `champiscompter-fichier-unique.html` (logo intégré, sans installation).
- Mise en ligne : voir `champiscompter/LISEZMOI.md` (Netlify Drop, GitHub Pages ou site de l'entreprise).

## Prochaine étape
Mettre le dossier en ligne en https, installer sur 1-2 téléphones, faire les premiers relevés réels
puis recaler coefficient de poids et taux de réalisation sur les pesées.
